/**
 * Package contains classes related to rendering.
 */
package me.gcx11.survivalgame.api.rendering;