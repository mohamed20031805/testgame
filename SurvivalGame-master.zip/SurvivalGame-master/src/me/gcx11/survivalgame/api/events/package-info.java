/**
 * Package with in-game events
 */
package me.gcx11.survivalgame.api.events;