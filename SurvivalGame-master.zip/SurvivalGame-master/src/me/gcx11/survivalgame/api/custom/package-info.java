/**
 * Package with custom data structures
 */
package me.gcx11.survivalgame.api.custom;