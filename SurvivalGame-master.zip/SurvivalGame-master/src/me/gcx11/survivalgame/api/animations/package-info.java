/**
 * Package providing classes and data structures for simplifying animations.
 */
package me.gcx11.survivalgame.api.animations;