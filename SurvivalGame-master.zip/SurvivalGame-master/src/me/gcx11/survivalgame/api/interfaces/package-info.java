/**
 * Package with interfaces
 */
package me.gcx11.survivalgame.api.interfaces;