/**
 * Package contains basic api used in game.
 */
package me.gcx11.survivalgame.api;