/**
 * Package contains very simple api for game input.
 */
package me.gcx11.survivalgame.api.input;