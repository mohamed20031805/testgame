/**
 * Package with API for additional plugins
 */
package me.gcx11.survivalgame.api.plugins;