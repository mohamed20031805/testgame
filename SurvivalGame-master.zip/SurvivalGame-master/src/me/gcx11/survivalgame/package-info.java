/**
 * Top level package for game.
 */
package me.gcx11.survivalgame;