/**
 * Package contains all inventory-like classes.
 */
package me.gcx11.survivalgame.objects.inventories;