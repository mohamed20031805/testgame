package me.gcx11.survivalgame.objects.items;

/**
 * Created on 15.5.2017.
 */
public enum ArmorType {
    NONE, SHIELD, HELMET, BODY, BOOTS, GLOVES
}
