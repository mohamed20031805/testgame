/**
 * Package contains item definitions and its subclasses.
 */
package me.gcx11.survivalgame.objects.items;