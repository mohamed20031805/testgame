/**
 * Package contains naturally generated objects in-game.
 */
package me.gcx11.survivalgame.objects.nature;