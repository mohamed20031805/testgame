/**
 * Package contains some user classes for easier creation of user interfaces.
 */
package me.gcx11.survivalgame.scenes.ui;