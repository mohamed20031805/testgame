/**
 * Package contains every game scene.
 */
package me.gcx11.survivalgame.scenes;