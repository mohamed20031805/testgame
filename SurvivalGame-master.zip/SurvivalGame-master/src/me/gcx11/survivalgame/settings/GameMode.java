package me.gcx11.survivalgame.settings;

/**
 * Created on 18.5.2017.
 */
public enum GameMode {
    EASY, HARDCORE
}
